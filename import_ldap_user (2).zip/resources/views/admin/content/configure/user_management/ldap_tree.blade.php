<li class="tree-item {{ !empty($children) || isset($children['groups']) ? 'has-children' : '' }}">
    @php
        $isGroupContainer = $node === 'groups';
    @endphp

    @unless($isGroupContainer)
        <div class="tree-node" style="--depth: {{ $level }}">
            {{-- Add checkbox at start of department --}}
            @if($level > 0) {{-- Only add checkbox for departments, not root nodes --}}
                <input type="checkbox" 
                       id="dept-{{ md5($node . $level) }}" 
                       class="department-checkbox" 
                       name="selected_departments[]" 
                       value="{{ $node }}"
                       data-ou-path="{{ $node }}"
                       style="margin-right: 10px;">
            @endif
            <span class="tree-label ou-label">
                <i class="fas fa-folder-open me-1"></i> {{ $node }}
            </span>
        </div>
    @endunless

    @if (!empty($children))
        <ul class="tree-children">
            @foreach ($children as $childNode => $childChildren)
                @if($childNode === 'groups')
                    {{-- Skip groups section - groups are now removed --}}
                @else
                    {{-- Normal department/node --}}
                    @include('admin.content.configure.user_management.ldap_tree', [
                        'node' => $childNode,
                        'children' => $childChildren,
                        'level' => $level + 1,
                        'parent' => $node
                    ])
                @endif
            @endforeach
        </ul>
    @endif
</li>
