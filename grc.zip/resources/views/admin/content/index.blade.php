@extends('admin/layouts/contentLayoutMaster')

@section('title', __('locale.Home'))

@section('content')
@endsection
