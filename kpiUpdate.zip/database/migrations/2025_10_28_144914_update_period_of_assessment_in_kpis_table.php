<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        DB::statement("ALTER TABLE kpis MODIFY period_of_assessment ENUM('1','3','6','9','12') NULL");
    }

    public function down(): void
    {
        // revert to string or previous type
        DB::statement("ALTER TABLE kpis MODIFY period_of_assessment VARCHAR(255) NULL");
    }
};